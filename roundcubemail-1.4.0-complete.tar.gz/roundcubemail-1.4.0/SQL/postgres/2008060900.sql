-- Updates from version 0.2-alpha

CREATE INDEX messages_created_idx ON messages (created);
